# OU Escape Route — Native Android v1

## App identity
- App name: **OU Escape Route**
- Package: `com.oukantanata.ouescaperoute`
- Launcher icon: the supplied neon OU Escape Route artwork
- Launch experience: branded Android splash screen

## Build
From the project root:

```bash
./gradlew assembleDebug
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Install directly:

```bash
./gradlew installDebug
```

If `gradlew` is not included in your checkout, generate it with a compatible Gradle installation:

```bash
gradle wrapper --gradle-version 8.1
```

## Implemented
- Game-first home screen
- Game Hub
- Social-account private vault
- Encrypted preferences
- Salted PIN verification
- PIN failure backoff policy
- Room persistence
- Settings and account clearing
- Mini App Store catalog shell
- Social OAuth provider abstraction
- Branded launcher icon and splash

## Production integrations
Provider OAuth for Facebook, Instagram, Twitter/X, TikTok, YouTube and Snapchat requires each provider's current developer credentials, redirect URI and approved scopes. The project does not contain fake credentials.

The Mini App Store is a catalog shell. Android package installation must use supported package-install APIs and user/system approval.
