# Build OU Escape Route APK on GitHub

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

## Steps
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository (the folder itself should be the repository root).
3. Push to `main` or `master`, or open **Actions → Build OU Escape Route APK → Run workflow**.
4. When the workflow finishes, open the workflow run and download the artifact named **OU-Escape-Route-debug-apk**.
5. The artifact contains `app-debug.apk`, which can be installed on a compatible Android device with installation from that source permitted.

The workflow uses JDK 17 and Gradle 8.1.1, generates the Gradle wrapper on the runner, and builds the debug APK.

## Important
- This is a debug APK, not a Play Store release build.
- Social OAuth providers still require their own developer-console credentials/configuration before real account linking can work.
- The current project is a functional native Android project/prototype; some game and mini-app functionality remains represented by the app's current implementation rather than being a full catalog of third-party apps.
