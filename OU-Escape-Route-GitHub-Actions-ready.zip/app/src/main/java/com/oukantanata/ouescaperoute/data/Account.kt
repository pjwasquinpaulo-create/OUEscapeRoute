package com.oukantanata.ouescaperoute.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "social_accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val platform: String,
    val displayName: String,
    val accountRef: String,
    val token: String
)
