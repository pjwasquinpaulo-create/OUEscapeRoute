package com.oukantanata.ouescaperoute.security

import kotlin.math.min

class UnlockPolicy {
    private var failures = 0
    private var lockedUntil = 0L

    fun canTry(now: Long = System.currentTimeMillis()) = now >= lockedUntil

    fun recordFailure(now: Long = System.currentTimeMillis()) {
        failures++
        val seconds = min(300, 2 shl min(failures - 1, 7))
        lockedUntil = now + seconds * 1000L
    }

    fun reset() {
        failures = 0
        lockedUntil = 0L
    }
}
